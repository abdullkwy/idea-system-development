import json
import time
from django.utils.deprecation import MiddlewareMixin
from django.utils import timezone
from django.conf import settings
from .models import VisitorTracking


class VisitorTrackingMiddleware(MiddlewareMixin):
    """
    Middleware لتتبع الزوار تلقائياً
    يسجل كل زيارة للموقع مع معلومات مفصلة عن الزائر
    """
    
    def __init__(self, get_response):
        self.get_response = get_response
        super().__init__(get_response)
    
    def process_request(self, request):
        """معالجة الطلب قبل الوصول للـ view"""
        # تسجيل وقت بداية الطلب
        request._visitor_tracking_start_time = time.time()
        return None
    
    def process_response(self, request, response):
        """معالجة الاستجابة بعد الـ view"""
        # تجاهل طلبات API والملفات الثابتة
        if self._should_track_request(request):
            self._track_visitor(request, response)
        
        return response
    
    def _should_track_request(self, request):
        """تحديد ما إذا كان يجب تتبع هذا الطلب"""
        # تجاهل طلبات API
        if request.path.startswith('/api/'):
            return False
        
        # تجاهل الملفات الثابتة
        static_extensions = ['.css', '.js', '.png', '.jpg', '.jpeg', '.gif', '.ico', '.svg', '.woff', '.woff2', '.ttf']
        if any(request.path.endswith(ext) for ext in static_extensions):
            return False
        
        # تجاهل طلبات AJAX
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return False
        
        # تجاهل طلبات البوتات (اختياري)
        user_agent = request.META.get('HTTP_USER_AGENT', '').lower()
        bot_indicators = ['bot', 'crawler', 'spider', 'scraper']
        if any(indicator in user_agent for indicator in bot_indicators):
            return False
        
        return True
    
    def _track_visitor(self, request, response):
        """تسجيل بيانات الزائر"""
        try:
            # حساب مدة الزيارة
            start_time = getattr(request, '_visitor_tracking_start_time', time.time())
            visit_duration = int((time.time() - start_time) * 1000)  # بالميلي ثانية
            
            # استخراج معلومات الطلب
            session_key = request.session.session_key or 'anonymous'
            ip_address = self._get_client_ip(request)
            user_agent = request.META.get('HTTP_USER_AGENT', '')
            referrer = request.META.get('HTTP_REFERER', '')
            
            # معلومات الصفحة
            page_url = request.build_absolute_uri()
            page_title = self._extract_page_title(response)
            
            # تحليل User Agent
            device_info = self._parse_user_agent(user_agent)
            
            # تحديد ما إذا كانت الزيارة bounce (زيارة صفحة واحدة فقط)
            is_bounce = self._is_bounce_visit(request, visit_duration)
            
            # معلومات الموقع الجغرافي (يمكن تحسينها باستخدام خدمة GeoIP)
            location_info = self._get_location_info(ip_address)
            
            # إنشاء سجل تتبع الزائر
            VisitorTracking.objects.create(
                session_key=session_key,
                ip_address=ip_address,
                user_agent=user_agent,
                referrer=referrer,
                page_url=page_url,
                page_title=page_title,
                visit_duration=visit_duration,
                is_bounce=is_bounce,
                device_type=device_info['device_type'],
                browser=device_info['browser'],
                operating_system=device_info['operating_system'],
                country=location_info['country'],
                city=location_info['city']
            )
            
        except Exception as e:
            # تسجيل الخطأ دون إيقاف الطلب
            if settings.DEBUG:
                print(f"خطأ في تتبع الزائر: {e}")
    
    def _get_client_ip(self, request):
        """الحصول على عنوان IP الحقيقي للعميل"""
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            ip = x_forwarded_for.split(',')[0].strip()
        else:
            ip = request.META.get('REMOTE_ADDR', '127.0.0.1')
        return ip
    
    def _extract_page_title(self, response):
        """استخراج عنوان الصفحة من HTML"""
        try:
            if hasattr(response, 'content') and response.get('Content-Type', '').startswith('text/html'):
                content = response.content.decode('utf-8', errors='ignore')
                # البحث عن تاج title
                import re
                title_match = re.search(r'<title[^>]*>(.*?)</title>', content, re.IGNORECASE | re.DOTALL)
                if title_match:
                    return title_match.group(1).strip()
        except:
            pass
        return 'صفحة غير محددة'
    
    def _parse_user_agent(self, user_agent):
        """تحليل User Agent لاستخراج معلومات الجهاز والمتصفح"""
        user_agent_lower = user_agent.lower()
        
        # تحديد نوع الجهاز
        device_type = 'desktop'
        if any(mobile in user_agent_lower for mobile in ['mobile', 'android', 'iphone']):
            device_type = 'mobile'
        elif any(tablet in user_agent_lower for tablet in ['tablet', 'ipad']):
            device_type = 'tablet'
        
        # تحديد المتصفح
        browser = 'غير محدد'
        if 'chrome' in user_agent_lower and 'edg' not in user_agent_lower:
            browser = 'Chrome'
        elif 'firefox' in user_agent_lower:
            browser = 'Firefox'
        elif 'safari' in user_agent_lower and 'chrome' not in user_agent_lower:
            browser = 'Safari'
        elif 'edg' in user_agent_lower:
            browser = 'Edge'
        elif 'opera' in user_agent_lower:
            browser = 'Opera'
        
        # تحديد نظام التشغيل
        operating_system = 'غير محدد'
        if 'windows' in user_agent_lower:
            operating_system = 'Windows'
        elif 'mac' in user_agent_lower and 'iphone' not in user_agent_lower and 'ipad' not in user_agent_lower:
            operating_system = 'macOS'
        elif 'linux' in user_agent_lower and 'android' not in user_agent_lower:
            operating_system = 'Linux'
        elif 'android' in user_agent_lower:
            operating_system = 'Android'
        elif 'iphone' in user_agent_lower or 'ipad' in user_agent_lower:
            operating_system = 'iOS'
        
        return {
            'device_type': device_type,
            'browser': browser,
            'operating_system': operating_system
        }
    
    def _is_bounce_visit(self, request, visit_duration):
        """تحديد ما إذا كانت الزيارة bounce"""
        # اعتبار الزيارة bounce إذا كانت أقل من 30 ثانية
        return visit_duration < 30000  # 30 ثانية بالميلي ثانية
    
    def _get_location_info(self, ip_address):
        """الحصول على معلومات الموقع الجغرافي"""
        # يمكن تحسين هذا باستخدام خدمة GeoIP مثل MaxMind
        # حالياً نعيد قيم افتراضية
        return {
            'country': 'المملكة العربية السعودية',
            'city': 'الرياض'
        }


class CORSMiddleware(MiddlewareMixin):
    """
    Middleware لإضافة headers الـ CORS
    يسمح للواجهة الأمامية بالوصول للـ APIs
    """
    
    def process_response(self, request, response):
        """إضافة headers الـ CORS"""
        response['Access-Control-Allow-Origin'] = '*'
        response['Access-Control-Allow-Methods'] = 'GET, POST, PUT, PATCH, DELETE, OPTIONS'
        response['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-Requested-With'
        response['Access-Control-Max-Age'] = '86400'
        
        return response
    
    def process_request(self, request):
        """معالجة طلبات OPTIONS للـ preflight"""
        if request.method == 'OPTIONS':
            from django.http import HttpResponse
            response = HttpResponse()
            response['Access-Control-Allow-Origin'] = '*'
            response['Access-Control-Allow-Methods'] = 'GET, POST, PUT, PATCH, DELETE, OPTIONS'
            response['Access-Control-Allow-Headers'] = 'Content-Type, Authorization, X-Requested-With'
            response['Access-Control-Max-Age'] = '86400'
            return response
        
        return None


class SecurityMiddleware(MiddlewareMixin):
    """
    Middleware لإضافة headers الأمان
    """
    
    def process_response(self, request, response):
        """إضافة headers الأمان"""
        # منع تضمين الموقع في iframe من مواقع أخرى
        response['X-Frame-Options'] = 'SAMEORIGIN'
        
        # منع تخمين نوع المحتوى
        response['X-Content-Type-Options'] = 'nosniff'
        
        # تفعيل حماية XSS في المتصفحات
        response['X-XSS-Protection'] = '1; mode=block'
        
        # إجبار استخدام HTTPS (في الإنتاج)
        if not settings.DEBUG:
            response['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
        
        return response

